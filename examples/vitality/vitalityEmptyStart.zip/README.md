# Sitecore Content SDK Next.js Sample Application

<!---
@TODO: Update link with appropriate page when avaiable
-->

[Documentation](https://doc.sitecore.com/xmc/en/developers/xm-cloud/sitecore-javascript-rendering-sdk--jss--for-next-js.html)
